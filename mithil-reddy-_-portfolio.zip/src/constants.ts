import { PortfolioData } from './types';

export const PORTFOLIO_DATA: PortfolioData = {
  name: "Mithil Reddy",
  role: "Computer Engineering Student",
  aboutMe: "A focused and passionate Computer Engineering student at Mahindra University with a strong foundation in software development, machine learning, and data analysis. I enjoy building responsive web applications and predictive models that solve real-world problems.",
  researchInterests: [
    "Machine Learning & Artificial Intelligence",
    "Predictive Analytics & Forecasting",
    "Data Science for Social Good",
    "Human-Computer Interaction"
  ],
  email: {
    personal: "Mithil.koppula2503@gmail.com",
    college: "se23ucse095@mahindrauniversity.edu.in"
  },
  phone: "(91) 7993526032",
  address: "1136, Phase 2, Mahindra University, Bahadurpally, Hyderabad, India – 500043",
  skills: {
    languages: ["C", "Python", "Java", "JavaScript", "HTML/CSS", "SQL", "MATLAB"],
    tools: ["Git/GitHub", "VS Code", "Postman", "node.js", "express.js"]
  },
  interests: {
    sports: ["Cricket", "Badminton", "Pickleball", "Chess"],
    general: ["Watching movies", "Reading books"]
  },
  education: [
    {
      degree: "Bachelor of Technology (Computer Engineering)",
      institution: "Mahindra University, Hyderabad",
      period: "Aug 2023 - Aug 2027",
      score: "CGPA: 8.04/10 (till 5th semester)",
      details: ["Relevant course work: Data Structures, Database Management Systems, Applied Time Series, Machine Learning, Operating Systems"]
    },
    {
      degree: "Intermediate",
      institution: "Narayana Junior College, Nallakunta",
      period: "June 2021 – March 2023",
      score: "Percentage: 96.2%"
    },
    {
      degree: "10th Grade",
      institution: "Narayana Olympiad School (SSC), Adibatla",
      period: "May 2020 – June 2021",
      score: "Percentage: 100%"
    }
  ],
  projects: [
    {
      title: "Interactive Web Based Quiz Application",
      period: "Aug 2025 – Dec 2025",
      description: "A comprehensive and engaging quiz platform designed for smooth interaction across devices.",
      githubUrl: "https://github.com/mithilreddy/quiz-app",
      tech: ["HTML", "CSS", "JavaScript"],
      highlights: [
        "Built a responsive quiz application with question navigation, answer validation, and countdown timer.",
        "Designed a mobile-friendly interface using semantic HTML and responsive CSS."
      ]
    },
    {
      title: "Employee Attrition & Salary Prediction",
      period: "Jan 2025 – May 2025",
      description: "Machine learning models to predict employee attrition and future salary trends using classification and regression techniques.",
      githubUrl: "https://github.com/mithilreddy/attrition-prediction",
      tech: ["Python", "Machine Learning", "Scikit-Learn"],
      highlights: [
        "Used Logistic Regression, Decision Trees, SVM, Random Forest, Ridge, and Lasso with evaluation metrics like F1-Score and ROC-AUC.",
        "Simulated salary growth and estimated financial impact of employee attrition using predictive analytics."
      ]
    },
    {
      title: "Day-Ahead Electric Load Forecasting",
      period: "Aug 2025 – Dec 2025",
      description: "Time-series models to forecast 24-hour electricity demand using the OPSD dataset.",
      githubUrl: "https://github.com/mithilreddy/load-forecasting",
      tech: ["Python", "SARIMA", "STL Decomposition", "Streamlit"],
      highlights: [
        "Built SARIMA/SARIMAX time-series models to forecast 24-hour electricity demand.",
        "Analyzed seasonal patterns using STL decomposition and visualized predictions through a Streamlit dashboard."
      ]
    }
  ]
};
