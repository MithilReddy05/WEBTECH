/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Project {
  title: string;
  description: string;
  period: string;
  githubUrl: string;
  highlights: string[];
  tech: string[];
}

export interface Education {
  degree: string;
  institution: string;
  period: string;
  details?: string[];
  score?: string;
}

export interface PortfolioData {
  name: string;
  role: string;
  aboutMe: string;
  researchInterests: string[];
  email: {
    personal: string;
    college: string;
  };
  phone: string;
  address: string;
  skills: {
    languages: string[];
    tools: string[];
  };
  interests: {
    sports: string[];
    general: string[];
  };
  education: Education[];
  projects: Project[];
}
