import { motion } from 'motion/react';
import { PORTFOLIO_DATA } from '../constants';
import { Github, Mail } from 'lucide-react';

export default function Projects() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <header className="mb-32 text-center">
        <motion.div
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8 }}
        >
          <h1 className="text-8xl md:text-9xl font-serif italic font-bold tracking-tight mb-8 text-accent">
            Curated<br />
            <span className="text-brand">Artifacts.</span>
          </h1>
          <p className="text-xl font-sans text-brand/60 max-w-2xl mx-auto leading-relaxed">
            A collection of digital solutions and computational experiments. 
            Each entry represents a milestone in technical exploration and human-centered design.
          </p>
        </motion.div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
        {PORTFOLIO_DATA.projects.map((project, idx) => (
          <motion.article 
            key={project.title}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: idx * 0.1 }}
            className="organic-card flex flex-col group overflow-hidden"
          >
            <div className="flex-grow space-y-6">
              <div className="flex justify-between items-start">
                <h2 className="text-3xl font-serif font-bold tracking-tight">
                  {project.title}
                </h2>
              </div>
              
              <p className="text-brand/70 text-base leading-relaxed font-sans">
                {project.description}
              </p>

              <div className="flex flex-wrap gap-2 pt-4">
                {project.tech.map(t => (
                  <span key={t} className="text-[10px] uppercase font-sans font-bold tracking-widest text-accent/60 bg-accent/5 px-4 py-1.5 rounded-full">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </motion.article>
        ))}
      </div>

      <motion.footer 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="mt-48 text-center"
      >
        <div className="max-w-xl mx-auto space-y-10">
          <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto text-accent mb-8">
            <Mail size={24} />
          </div>
          <h2 className="text-5xl font-serif italic font-bold">Curious about the process?</h2>
          <p className="text-brand/60 font-sans leading-relaxed">
            I am always open to discussing technical architecture, design philosophy, or potential collaborations. 
            Do not hesitate to reach out.
          </p>
          <a 
            href={`mailto:${PORTFOLIO_DATA.email.personal}`}
            className="inline-block px-12 py-5 bg-accent text-surface rounded-full font-sans font-bold uppercase text-[10px] tracking-[0.3em] hover:scale-105 transition-transform"
          >
            Initiate Conversation
          </a>
        </div>
      </motion.footer>
    </div>
  );
}
