import { motion } from 'motion/react';
import { PORTFOLIO_DATA } from '../constants';

export default function Home() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-12 lg:py-24">
      {/* Hero Section */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-32">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h1 className="text-7xl md:text-9xl font-serif italic font-bold tracking-tight mb-8 leading-[0.85] text-accent">
            Human<br />
            <span className="text-brand">Learning.</span>
          </h1>
          <p className="text-xl font-sans text-brand/70 leading-relaxed mb-10 max-w-lg">
            {PORTFOLIO_DATA.aboutMe}
          </p>
          <div className="flex flex-wrap gap-8 items-center">
            <a 
              href="#interests"
              className="px-10 py-4 bg-accent text-surface font-bold uppercase tracking-widest text-[10px] rounded-full hover:scale-105 transition-transform"
            >
              Explore Interests
            </a>
            <div className="flex -space-x-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-surface bg-brand/10 overflow-hidden">
                  <img src={`https://picsum.photos/seed/user-${i}/100/100`} alt="Avatar" referrerPolicy="no-referrer" />
                </div>
              ))}
              <div className="w-10 h-10 rounded-full border-2 border-surface bg-accent flex items-center justify-center text-[10px] text-surface font-bold">
                +
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, rotate: 5 }}
          animate={{ opacity: 1, rotate: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative max-w-md mx-auto lg:ml-auto w-full"
        >
          <img 
            src="https://picsum.photos/seed/mithil-warm/800/1000" 
            alt="Profile" 
            referrerPolicy="no-referrer"
            className="pill-image-mask shadow-2xl rotate-[-3deg] hover:rotate-0 transition-transform duration-700"
          />
          <div className="absolute -bottom-6 -right-6 w-32 h-40 bg-accent rounded-3xl -z-10 rotate-12"></div>
        </motion.div>
      </section>

      {/* Research Interests */}
      <section id="interests" className="mb-32 py-24 bg-card rounded-[64px] border border-brand/5 px-8 md:px-20 text-center">
        <h2 className="text-[10px] font-sans font-bold uppercase tracking-[0.4em] text-accent/60 mb-16">Areas of Inquiry</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {PORTFOLIO_DATA.researchInterests.map((interest, idx) => (
            <motion.div 
              key={interest}
              whileHover={{ scale: 1.05 }}
              className="space-y-6"
            >
              <span className="inline-block text-4xl font-serif italic text-accent/30 tracking-tighter">0{idx + 1}</span>
              <h3 className="font-serif font-bold text-2xl leading-tight border-t border-brand/5 pt-6">{interest}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Education & Experience */}
      <section className="mb-32 grid grid-cols-1 lg:grid-cols-2 gap-20">
        <div>
           <h2 className="text-5xl font-serif font-bold italic mb-12 text-accent">Academic Journey</h2>
           <div className="space-y-16">
              {PORTFOLIO_DATA.education.map((edu, idx) => (
                <div key={idx} className="relative pl-10 border-l border-accent/10">
                  <div className="absolute left-[-4px] top-0 w-2 h-2 bg-accent rounded-full"></div>
                  <h3 className="text-2xl font-serif font-bold mb-2">{edu.degree}</h3>
                  <p className="text-sm font-sans font-bold uppercase tracking-widest text-accent/60 mb-4">{edu.period}</p>
                  <p className="text-lg font-serif italic opacity-70 mb-4">{edu.institution}</p>
                  {edu.details?.map((detail, i) => (
                    <p key={i} className="text-sm font-sans opacity-60 leading-relaxed">{detail}</p>
                  ))}
                </div>
              ))}
           </div>
        </div>

        <div className="bg-accent text-surface p-12 lg:p-20 rounded-[64px] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
          <h2 className="text-[10px] font-sans font-bold uppercase tracking-[0.4em] opacity-50 mb-12">Technical Toolkit</h2>
          <div className="space-y-12 relative z-10">
            <div>
              <h3 className="font-serif italic text-2xl mb-6 opacity-80">Syntactic Capabilities</h3>
              <div className="flex flex-wrap gap-3">
                {PORTFOLIO_DATA.skills.languages.map(skill => (
                  <span key={skill} className="px-5 py-2 border border-surface/20 rounded-full text-xs font-sans uppercase tracking-wider hover:bg-surface hover:text-accent transition-colors cursor-default">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            <div>
               <h3 className="font-serif italic text-2xl mb-6 opacity-80">Operational Frameworks</h3>
               <div className="flex flex-wrap gap-3">
                {PORTFOLIO_DATA.skills.tools.map(tool => (
                  <span key={tool} className="px-5 py-2 bg-surface/10 rounded-full text-xs font-sans uppercase tracking-wider hover:bg-surface hover:text-accent transition-colors cursor-default">
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
