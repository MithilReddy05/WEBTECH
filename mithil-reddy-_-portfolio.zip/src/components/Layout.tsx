import React from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X, Github, Mail, Phone, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PORTFOLIO_DATA } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen flex flex-col font-display">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-surface/90 backdrop-blur-sm border-b border-brand/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <NavLink to="/" className="text-2xl font-serif font-bold italic tracking-tight text-accent">
            {PORTFOLIO_DATA.name.split(' ').map(n => n[0]).join('.')}
          </NavLink>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-12 font-sans text-sm font-medium">
            <NavLink 
              to="/" 
              className={({ isActive }) => isActive ? "nav-link-active" : "hover:text-accent transition-colors"}
            >
              Overview
            </NavLink>
            <NavLink 
              to="/projects" 
              className={({ isActive }) => isActive ? "nav-link-active" : "hover:text-accent transition-colors"}
            >
              Curated Work
            </NavLink>
          </div>

          {/* Contact Button */}
          <div className="hidden md:block">
            <a 
              href={`mailto:${PORTFOLIO_DATA.email.personal}`}
              className="px-6 py-2 border border-brand/20 rounded-full text-xs font-semibold uppercase tracking-widest hover:bg-accent hover:border-accent hover:text-surface transition-all"
            >
              Let's Talk
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden text-accent"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-20 left-0 w-full bg-surface border-b border-brand/10 md:hidden flex flex-col p-6 gap-6 font-serif text-2xl italic"
            >
              <NavLink 
                to="/" 
                onClick={() => setIsMenuOpen(false)}
                className={({ isActive }) => isActive ? "text-accent" : ""}
              >
                Overview
              </NavLink>
              <NavLink 
                to="/projects" 
                onClick={() => setIsMenuOpen(false)}
                className={({ isActive }) => isActive ? "text-accent" : ""}
              >
                Curated Work
              </NavLink>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="footer-area py-20 px-6 mt-20 border-t border-brand/5 bg-card/30">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between gap-16">
          <div className="max-w-md">
            <h2 className="text-4xl font-serif italic mb-6 text-accent">{PORTFOLIO_DATA.name}</h2>
            <p className="text-brand/60 leading-relaxed font-sans mb-8">
              Boutique software crafting and intelligent systems design. 
              Currently exploring the intersections of human behavior and predictive logic.
            </p>
            <div className="flex gap-4">
              <a href={`mailto:${PORTFOLIO_DATA.email.personal}`} className="p-3 border border-brand/10 rounded-full hover:bg-brand hover:text-surface transition-colors">
                <Mail size={18} />
              </a>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-12">
            <div className="space-y-4">
              <h3 className="font-sans font-bold uppercase tracking-widest text-[10px] text-accent/50">Location</h3>
              <p className="text-sm font-sans">Hyderabad,<br />India</p>
            </div>
            <div className="space-y-4">
              <h3 className="font-sans font-bold uppercase tracking-widest text-[10px] text-accent/50">Current Role</h3>
              <p className="text-sm font-sans">{PORTFOLIO_DATA.role}</p>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-brand/5 flex justify-between items-center text-[10px] font-sans opacity-40 uppercase tracking-[0.2em]">
          <p>© {new Date().getFullYear()} Mithil Reddy Portfolio</p>
          <div className="flex gap-6">
            <span>Mahindra University</span>
            <span>All rights reserved</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
